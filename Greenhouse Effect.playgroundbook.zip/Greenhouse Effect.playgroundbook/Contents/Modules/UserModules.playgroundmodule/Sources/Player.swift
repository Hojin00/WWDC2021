
// Code inside modules can be shared between pages and other source files.


import AVFoundation

open class Player {
    var audioPlayer: AVAudioPlayer?
    
    open init(_ music: String = "background") {
        if let path = Bundle.main.path(forResource: music, ofType: "mp3") {
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))
                audioPlayer?.numberOfLoops = -1
                audioPlayer?.volume = 0.2
            } catch {
                print("ERROR")
     
            }
        }
    }
    
    open func play() {
        audioPlayer?.play()
    }
}
