//#-hidden-code
import PlaygroundSupport
import Foundation
import SwiftUI

struct ContentView: View {
    
    var body: some View {
        ZStack {
            Image(uiImage: #imageLiteral(resourceName: "sky.png"))
                .resizable()
                .frame(width:1000, height:1300)
                .offset(y:-300)
            VStack {
                ZStack {
                    SunEnergyGround()
                    
                    CarbonDioxide()
                    
                    Methane()
                    
                    Cloud()
                    
                }
                Image(uiImage: #imageLiteral(resourceName: "Ground-2.png"))
                    .resizable()
                    .frame(width:1000, height:600)
                    .offset(y:30)
                
            }
        }
    }
}

struct SunEnergyGround: View {
    @State var positionX1 = -200
    @State var positionY1 = 150
    
    @State var positionX2 = -350
    @State var positionY2 = 250
    
    
    var body: some View {
        ZStack {
            Image(uiImage: #imageLiteral(resourceName: "sunlight.png"))
                .resizable()
                .frame(width: 130, height: 130)
                .rotationEffect(.degrees(-25))
                .offset(x: CGFloat(positionX1))
                .offset(y: CGFloat(positionY1))
                .animation(Animation.easeInOut(duration: 3).repeatForever(autoreverses: true).speed(3))
                .onAppear(){
                    positionX1 += 100
                    positionY1 += 280
                }
                .opacity(0.8)
            
            Image(uiImage: #imageLiteral(resourceName: "sunlight.png"))
                .resizable()
                .frame(width: 130, height: 130)
                .rotationEffect(.degrees(-25))
                .offset(x: CGFloat(positionX2))
                .offset(y: CGFloat(positionY2))
                .animation(Animation.easeInOut(duration: 3).repeatForever(autoreverses: true).speed(3))
                .onAppear(){
                    positionX2 += 100
                    positionY2 += 280
                }
                .opacity(0.8)
            
            
            
        }
        
        
    }
}

struct CarbonDioxide: View {
    @State var randomCloud = Int.random(in: 2...5)
    @State var isAnimating: Bool = false
    
    func randomCoordinate(max: CGFloat) -> CGFloat{
        return CGFloat.random(in: 300...max)
    }
    
    func randomSizeWidth() -> CGFloat{
        return CGFloat(Int.random(in: 50...110))
    }
    
    func randomSizeHeight() -> CGFloat{
        return CGFloat(Int.random(in: 50...110))
    }
    
    func randomScale() -> CGFloat{
        return CGFloat(Double.random(in: 0.1...1.5))
    }
    
    func randomSpeed() -> Double {
        return Double.random(in: 0.025...1.0)
    }
    
    func randomDelay() -> Double {
        return Double.random(in: 0...2)
    }
    var body: some View {
        
        GeometryReader{ geometry in
            
            ZStack {
                ForEach(0...randomCloud, id: \.self) { item in
                    Image(uiImage: #imageLiteral(resourceName: "co2.png"))
                        .resizable()
                        .opacity(0.45)
                        .frame(width: randomSizeWidth(), height: randomSizeHeight(), alignment: .center)
                        .scaleEffect(isAnimating ? randomScale() : 1)
                        .position(
                            x: randomCoordinate(max: geometry.size.width),
                            y: geometry.size.height
                        )
                        .animation(
                            Animation.interpolatingSpring(stiffness: 0.5, damping: 0.3)
                                .repeatForever()
                                .speed(randomSpeed())
                                .delay(randomDelay())
                        )
                        .onAppear(
                            perform: {
                                isAnimating = true
                            }
                        )
                }
            }.drawingGroup()
        }
    }
}

struct Methane: View {
    @State var randomCloud = Int.random(in: 2...4)
    @State var isAnimating: Bool = false
    
    func randomCoordinateX(max: CGFloat) -> CGFloat{
        return CGFloat.random(in: 150...max)
    }
    
    func randomSizeWidth() -> CGFloat{
        return CGFloat(Int.random(in: 50...110))
    }
    
    func randomSizeHeight() -> CGFloat{
        return CGFloat(Int.random(in: 50...110))
    }
    
    func randomScale() -> CGFloat{
        return CGFloat(Double.random(in: 0.1...1.5))
    }
    
    func randomSpeed() -> Double {
        return Double.random(in: 0.025...1.0)
    }
    
    func randomDelay() -> Double {
        return Double.random(in: 0...2)
    }
    var body: some View {
        
        GeometryReader{ geometry in
            
            ZStack {
                ForEach(0...randomCloud, id: \.self) { item in
                    Image(uiImage: #imageLiteral(resourceName: "methane.png"))
                        .resizable()
                        .opacity(0.45)
                        .frame(width: randomSizeWidth(), height: randomSizeHeight(), alignment: .center)
                        .scaleEffect(isAnimating ? randomScale() : 1)
                        .position(
                            x: randomCoordinateX(max: geometry.size.width),
                            y: geometry.size.height / 2
                        )
                        .animation(
                            Animation.interpolatingSpring(stiffness: 0.5, damping: 0.3)
                                .repeatForever()
                                .speed(randomSpeed())
                                .delay(randomDelay())
                        )
                        .onAppear(
                            perform: {
                                isAnimating = true
                            }
                        )
                }
            }.drawingGroup()
        }
    }
}

struct Cloud: View {
    @State var randomCloud = Int.random(in: 2...5)
    @State var isAnimating: Bool = false
    
    func randomCoordinate(max: CGFloat) -> CGFloat{
        return CGFloat.random(in: 0...max)
    }
    
    func randomSizeWidth() -> CGFloat{
        return CGFloat(Int.random(in: 130...150))
    }
    
    func randomSizeHeight() -> CGFloat{
        return CGFloat(Int.random(in: 100...130))
    }
    
    func randomScale() -> CGFloat{
        return CGFloat(Double.random(in: 0.1...1.5))
    }
    
    func randomSpeed() -> Double {
        return Double.random(in: 0.025...1.0)
    }
    
    func randomDelay() -> Double {
        return Double.random(in: 0...2)
    }
    var body: some View {
        
        GeometryReader{ geometry in
            
            ZStack {
                ForEach(0...randomCloud, id: \.self) { item in
                    Image(uiImage: #imageLiteral(resourceName: "cloud.png"))
                        .resizable()
                        .opacity(0.45)
                        .frame(width: randomSizeWidth(), height: randomSizeHeight(), alignment: .center)
                        .scaleEffect(isAnimating ? randomScale() : 1)
                        .position(
                            x: randomCoordinate(max: geometry.size.width),
                            y: geometry.size.height / 5
                        )
                        .animation(
                            Animation.interpolatingSpring(stiffness: 0.5, damping: 0.3)
                                .repeatForever()
                                .speed(randomSpeed())
                                .delay(randomDelay())
                        )
                        .onAppear(
                            perform: {
                                isAnimating = true
                            }
                        )
                }
            }.drawingGroup()
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())

//#-end-hidden-code

//: _**Let's take a closer look on the Greenhouse Effect!**_

/*:

 - Note:
     The Earth doens't absorb 100% of 🌞solar energy
 
 */


/*:

 # How does the greenhouse effect actually occurs?

 
 What about in the Earth?
 1. Lands and oceans absorb solar energy.
 2. Heat radiates energy from Earth to space.
 3. Greenhouse gases traps some of those heats in the atmosphere to maintain comfortable temperature of the Earth.
 4. Humans activities such as burning fossil fuels, agriculture increase the amount of greenhouse gases in the atmosphere.
 5. Extra heats trapped and exceeds the adeqaute amount of heat in the atmosphere.
 

 */


/*:
 
 Now let's take a quiz about how we can save our Earth in real life!
 \
 [Next Topic](@next)
 
 */
