//#-hidden-code
import PlaygroundSupport
import Foundation
import SwiftUI




struct ContentView: View {
    
    
    @State var choice:Bool = false
    
    @State var button1 = false
    @State var rightWrong1:Color = .white
    
    @State var button2 = false
    @State var rightWrong2:Color = .white
    
    @State var button3 = false
    @State var rightWrong3:Color = .white
    
    @State var button4Answer = false
    
    
    @State var scaleXY = 1.0
    
    var body: some View {
        
        VStack {
            Text("Transportation  🚘")
                .italic()
                .font(.system(size: 80.0))
                .fontWeight(.bold)
                .foregroundColor(Color.blue)
                .padding()
            Divider()
            Text("Which one is wrong solution?")
                .italic()
                .font(.system(size: 40.0))
                .fontWeight(.bold)
                .padding()
            
            ZStack {
            
                Rectangle()
                    .opacity(0.2)
                    .frame(width:900, height:900)
                    .background((AngularGradient(gradient: Gradient(colors: [Color.white, Color.green]), center: .bottomTrailing)))
                    .offset(y:50)
                    
                VStack(spacing: 50) {
                    Button(action: {//Button 1
                        button1.toggle()
                        choice.toggle()
                        
                    }){
                        Text("Driving electric cars")
                            .frame(width: 550, height:50)
                            .font(.system(size: 30))
                            .padding()
                            .foregroundColor(.white)
                            .overlay(RoundedRectangle(cornerRadius: 25).stroke(rightWrong1, lineWidth: 5))
                            
                    }.padding()
                    
                    Button(action: {//Button 2
                        button2.toggle()
                        choice.toggle()
                    }){
                        Text("Walking and biking")
                            .frame(width: 550, height:50)
                            .font(.system(size: 30))
                            .padding()
                            .foregroundColor(.white)
                            .overlay(RoundedRectangle(cornerRadius: 25).stroke(rightWrong2, lineWidth: 5))
                            
                    }.padding()
                    
                    Button(action: {//Button 3
                        button3.toggle()
                        choice.toggle()
                    }){
                        Text("Making sure if your car is running efficiently")
                            .frame(width: 550, height:50)
                            .font(.system(size: 28))
                            .padding()
                            .foregroundColor(.white)
                            .overlay(RoundedRectangle(cornerRadius: 25).stroke(rightWrong3, lineWidth: 5))
                    }.padding()
                    
                    Button(action: {//Button 4
                        withAnimation{
                            choice.toggle()
                        }
                        
                    }){
                        Text("Driving a car as much as possible")
                            .frame(width: 550, height:50)
                            .font(.system(size: 30))
                            .padding()
                            .foregroundColor(.white)
                            .overlay(RoundedRectangle(cornerRadius: 25).stroke(button4Answer ? Color.green : Color.white, lineWidth: 5))
                            .scaleEffect(button4Answer ? CGFloat(scaleXY) : 1.0)
                    }.padding()
                }.offset(y: -30)
                
                if choice {//Button submit
                    Button(action: {
                        withAnimation{
                            
                            self.button4Answer.toggle()
                            scaleXY += 0.3
                            if button1 {
                                rightWrong1 = .red
                            } else if button2 {
                                rightWrong2 = .red
                            } else if button3 {
                                rightWrong3 = .red
                            }
                            
                        }
                    }){
                        Text("Submit")
                            .frame(width: 400, height:80)
                            .font(.system(size: 50))
                            .padding()
                            .foregroundColor(.white)
                            .overlay(RoundedRectangle(cornerRadius: 25).stroke(Color.yellow, lineWidth: 5))
                    }
                    .padding()
                    .offset(y:370)
                }
                
            }
        }
    }
       
}

PlaygroundPage.current.setLiveView(ContentView())
//#-end-hidden-code

/*:

 - Note:
     What can we do with our personal vehicles?

 **Run the code to begin the quiz!**
 
[Next Question](@next)
 
 */


