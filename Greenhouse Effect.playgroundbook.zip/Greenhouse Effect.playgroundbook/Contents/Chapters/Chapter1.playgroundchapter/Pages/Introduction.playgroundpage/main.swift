//#-hidden-code
import PlaygroundSupport
import SwiftUI


struct ContentView: View {
    
    
    @State var spining:Bool = false
    
    var body: some View {
        VStack(spacing: 100){
            Text("Greenhouse Effect")
                .font(.system(size: 80.0))
                .fontWeight(.bold)
                .foregroundColor(Color.blue)
            
            ZStack {
                Circle()
                    .overlay(Circle()
                                .stroke(Color.gray, lineWidth:4)
                                .background( AngularGradient(gradient: Gradient(colors: [Color.black, Color.blue]), center: .top)))
                    .frame(width:700, height:700)
                
                Image(uiImage: #imageLiteral(resourceName: "earth.png"))
                    .resizable()
                    .frame(width:500, height: 500)
                    .opacity(0.6)
                    .rotationEffect(.degrees(spining ? 360 : 0))
                    .animation(Animation.linear(duration: 3.0).repeatForever(autoreverses: false).speed(0.3))
                    .onAppear(){
                        self.spining.toggle()
                    }
                
            }.mask(Circle()).rotationEffect(.degrees(180)).animation(.easeIn)
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())
//#-end-hidden-code

/*:

 # Greenhouse Effect
 
 Greenhouse Effect is a process that occurs when gases in Earth's atmosphere trap the Sun's heat
 
 */

/*:

 
 **Greenhouse gases are essential gases for warming up the Earth and keep Earth's climate habitable for humans**
 
There are three major greenhouse gases:
 1. Carbon dioxide
 2. Methane
 3. Nitrous oxide
 */

/*:

 
# Why we have to care about greenhouse effect?
 
 As mentioned before, greenhouse gases are not bad!
 
 The point here is that they are just exceeding the adequate amount of Sun's heat energy to warm up the Earth.
 
 Consequently, [global warming](glossary://globalwarming) goes much higher and affects our climate system.
 

*/

/*:

 - Note:
    Levels of carbon dioxide peaked at 410.5 parts per million in 2019, according to the WMO. The annual increase is larger than the previous year and surpasses the average over the last decade.
 */

//: [Next Topic](@next)
