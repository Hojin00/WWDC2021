//#-hidden-code
import PlaygroundSupport
import Foundation
import SwiftUI

struct ContentView: View {
    
    var body: some View {
        ZStack {
            SpaceBackground()
            
            SunEnergy()
            SunEnergy2()
            
            VStack {
                
                Sun()
                    .padding(400)
                    .offset(x:-300)
                    .offset(y:-30)
                
                EarthInSpace()
                    .padding()
                    .offset(x:150)
                
            }
        }.background(Color.black)
        
    }
}

struct SpaceBackground: View {
    
    var starsPerRow = 10
    
    @State var isAnimating:Bool = false
    var body: some View {
        VStack(spacing:0){
            ForEach(0..<getNumberOfRows()){_ in
                HStack(spacing:10) {
                    ForEach(0..<self.starsPerRow){_ in
                        Image(uiImage: #imageLiteral(resourceName: "sparkles.png"))
                            
                            .frame(width:UIScreen.main.bounds.width/CGFloat(self.starsPerRow), height: UIScreen.main.bounds.width/CGFloat(self.starsPerRow))
                            
                            .opacity(self.isAnimating ? 1 : 0)
                            .animation(
                                Animation
                                    .linear(duration: Double.random(in: 1.0...2.0))
                                    .repeatForever(autoreverses: true)
                                    .delay(Double.random(in: 0...1.5)))
                    }
                }
                
            }
            
        }.onAppear(){
            self.isAnimating = true
        }
        
    }
    
    func getNumberOfRows() -> Int{
        let heightPerStar = UIScreen.main.bounds.width/CGFloat(self.starsPerRow)
        return Int(UIScreen.main.bounds.height/heightPerStar) + 1
    }
}

struct EarthInSpace: View {
    @State var spining:Bool = false
    
    var body: some View {
        
        ZStack {
            Circle()
                .overlay(Circle()
                            .stroke(Color.gray, lineWidth:4)
                            .background( AngularGradient(gradient: Gradient(colors: [Color.black, Color.blue]), center: .top)))
                .frame(width:700, height:700)
            
            Image(uiImage: #imageLiteral(resourceName: "earth.png"))
                .resizable()
                .frame(width:500, height: 500)
                .opacity(0.6)
                .rotationEffect(.degrees(spining ? 360 : 0))
                .animation(Animation.linear(duration: 3.0).repeatForever(autoreverses: false).speed(0.3))
                .onAppear(){
                    self.spining.toggle()
                }
            
        }.mask(Circle()).rotationEffect(.degrees(180)).animation(.easeIn)
        
        
    }
}

struct Sun: View {
    var body: some View {
        Image(uiImage: #imageLiteral(resourceName: "sun.png"))
            .resizable()
            .frame(width:250.0, height:250.0)
        
    }
}

struct SunEnergy: View {
    
    @State var positionX1 = -200
    @State var positionY1 = -310
    
    
    var body: some View {
        Image(uiImage: #imageLiteral(resourceName: "sunlight.png"))
            .resizable()
            .frame(width: 80, height: 80)
            .rotationEffect(.degrees(-25))
            .offset(x: CGFloat(positionX1))
            .offset(y: CGFloat(positionY1))
            .animation(Animation.easeInOut(duration: 3).repeatForever(autoreverses: true).speed(3))
            .onAppear(){
                positionX1 += 200
                positionY1 += 480
            }
        
    }
}

struct SunEnergy2: View {
    
    @State var positionX1 = -200
    @State var positionY1 = -310
    
    
    var body: some View {
        Image(uiImage: #imageLiteral(resourceName: "sunlight.png"))
            .resizable()
            .frame(width: 80, height: 80)
            .rotationEffect(.degrees(-25))
            .offset(x: CGFloat(positionX1))
            .offset(y: CGFloat(positionY1))
            .animation(Animation.easeInOut(duration: 3).repeatForever(autoreverses: true).speed(3))
            .onAppear(){
                positionX1 += 100
                positionY1 += 530
            }
        
    }
}

PlaygroundPage.current.setLiveView(ContentView())
//#-end-hidden-code

//: _**Let's take a closer look on the Greenhouse Effect!**_

/*:

 - Note:
    The Earth always absorbs 🌞solar energy to maintain comfortable temperature
 
 */


/*:

 # How does the greenhouse effect actually occurs?

 
 Let's start from the Sun!
 1. Solar energy reaches the Earth's atmosphere
 2. Some of this is reflected back into space.
 3. Earth receives the rest of the solar energy.
 

 */

/*:
 
 **What about in the Earth?**
 \
 [Next Topic](@next)
 */

